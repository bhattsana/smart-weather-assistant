# ◎ NIMBUS — Weather Intelligence App

A production-grade, fully responsive weather application with a glassmorphism UI, real-time data, voice search, and dynamic weather-based themes.

![NIMBUS Preview](assets/preview-placeholder.png)

---

## ✨ Features

### Core
- 🌍 **City Search** — search any city globally with autocomplete suggestions
- 📍 **Auto-Detect Location** — one-click GPS-based weather via Geolocation API
- 🌡 **Current Weather** — temperature, feels like, humidity, wind, pressure, visibility, sunrise/sunset
- 📊 **7-Day Forecast** — daily high/low, icons, and conditions
- ⏱ **Hourly Forecast** — 24-hour horizontal scroll strip
- 📈 **Temperature Chart** — interactive 48-hour trend via Chart.js

### Advanced
- 🎤 **Voice Search** — speak a city name using the Web Speech API (Chrome/Edge)
- 🌙 **Dark / Light Mode** — persistent theme toggle
- °C / °F **Unit Toggle** — switch between metric and imperial
- 💾 **Local Storage** — remembers last city, recent searches, unit, and theme
- 🎨 **Dynamic Backgrounds** — background orbs change based on weather condition
- 🌧 **Animated Rain** — live raindrop animation for rainy conditions
- ☀ **Floating Particles** — subtle ambient particles for sunny skies
- 🤖 **AI Suggestions** — contextual tips ("Carry umbrella ☔", "Stay hydrated 💧")
- ❌ **Graceful Error Handling** — city not found, API key errors, permission denied
- ⏳ **Loading Spinner** — animated multi-ring loader while fetching

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Markup | HTML5 (semantic) |
| Styles | CSS3 — Flexbox, Grid, custom properties, animations |
| Logic | Vanilla JavaScript ES6+ (async/await, modules pattern) |
| Charts | [Chart.js](https://www.chartjs.org/) via CDN |
| Fonts | Google Fonts — Outfit + Space Mono |
| API | [OpenWeatherMap](https://openweathermap.org/) (free tier) |

---

## 📁 Project Structure

```
weather-app/
├── index.html          # App shell with all markup
├── style.css           # All styles — themes, layout, animations
├── script.js           # Full JS logic — API, render, state, events
├── assets/             # Icons, images (add your own)
└── README.md           # This file
```

---

## 🚀 Setup Instructions

### 1. Get a Free API Key

1. Visit [https://openweathermap.org/api](https://openweathermap.org/api)
2. Sign up for a free account
3. Navigate to **API keys** in your account dashboard
4. Copy your key (takes ~10 minutes to activate)

### 2. Add Your API Key

Open `script.js` and replace the placeholder on line 18:

```js
const CONFIG = {
  API_KEY: 'YOUR_API_KEY_HERE',  // ← Paste your key here
  ...
};
```

### 3. Run the App

Open `index.html` in any modern browser, or use a local server:

```bash
# Option A — VS Code Live Server (recommended)
# Install "Live Server" extension, then right-click index.html → Open with Live Server

# Option B — Python
python -m http.server 8080

# Option C — Node.js
npx serve .
```

> **Note:** Voice search and Geolocation require `https://` or `localhost`.

---

## 🔑 API Key Usage

This app uses two OpenWeatherMap endpoints:

| Endpoint | Used For |
|----------|----------|
| `/data/2.5/weather` | Current weather by city or coords |
| `/data/2.5/forecast` | 5-day / 3-hour forecast data |
| `/geo/1.0/direct` | Autocomplete city suggestions |

The **free tier** supports up to **60 API calls/minute** and **1,000,000 calls/month** — more than enough for personal use.

---

## 🎨 Weather Themes

The background automatically adapts based on conditions:

| Condition | Theme |
|-----------|-------|
| ☀ Clear / Sunny | Warm amber orbs |
| 🌧 Rain / Drizzle | Deep blue, animated raindrops |
| ⛈ Thunderstorm | Dark purple |
| ❄ Snow | Ice blue |
| 🌫 Fog / Mist | Default neutral |
| 🌙 Night | Deep space dark |

---

## 📸 Screenshots

> _Add screenshots here after running the app_

| Dark Mode | Light Mode |
|-----------|------------|
| ![dark](assets/dark-preview.png) | ![light](assets/light-preview.png) |

---

## 🔮 Planned Enhancements

- [ ] Air Quality Index (AQI) card
- [ ] UV Index with risk scale
- [ ] Weather alerts/warnings
- [ ] PWA support (install as app)
- [ ] Multiple city comparison
- [ ] Historical weather data

---

## 📄 License

MIT © 2025 — Free to use and modify.

---

> Built with ♥ using vanilla HTML, CSS, and JavaScript. No frameworks, no build tools, just the web platform.

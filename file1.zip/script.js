/**
 * NIMBUS WEATHER APP — script.js
 * Production-ready vanilla JS weather application
 * Uses OpenWeatherMap API (free tier)
 *
 * SETUP: Replace API_KEY below with your key from
 *        https://openweathermap.org/api
 */

'use strict';

/* ════════════════════════════════════════════════════
   CONFIG
════════════════════════════════════════════════════ */

const CONFIG = {
  // ⚠ Replace with your OpenWeatherMap API key
  API_KEY: 'YOUR_API_KEY_HERE',
  BASE_URL: 'https://api.openweathermap.org/data/2.5',
  GEOCODE_URL: 'https://api.openweathermap.org/geo/1.0',
  MAX_RECENT: 5,
  STORAGE_KEYS: {
    RECENT: 'nimbus_recent',
    LAST_CITY: 'nimbus_last_city',
    UNIT: 'nimbus_unit',
    THEME: 'nimbus_theme',
  },
};

/* ════════════════════════════════════════════════════
   STATE
════════════════════════════════════════════════════ */

const state = {
  unit: 'metric',          // 'metric' | 'imperial'
  theme: 'dark',           // 'dark' | 'light'
  currentWeather: null,
  forecastData: null,
  chartInstance: null,
  isLoading: false,
  recentCities: [],
};

/* ════════════════════════════════════════════════════
   DOM REFERENCES
════════════════════════════════════════════════════ */

const $ = (id) => document.getElementById(id);

const DOM = {
  cityInput: $('cityInput'),
  searchBtn: $('searchBtn'),
  voiceBtn: $('voiceBtn'),
  locationBtn: $('locationBtn'),
  unitToggle: $('unitToggle'),
  unitToggleMobile: $('unitToggleMobile'),
  themeToggle: $('themeToggle'),
  themeIcon: $('themeIcon'),
  loadingOverlay: $('loadingOverlay'),
  emptyState: $('emptyState'),
  weatherDashboard: $('weatherDashboard'),
  errorMsg: $('errorMsg'),
  cityName: $('cityName'),
  countryName: $('countryName'),
  localTime: $('localTime'),
  tempMain: $('tempMain'),
  tempUnit: $('tempUnit'),
  feelsLike: $('feelsLike'),
  conditionBadge: $('conditionBadge'),
  aiSuggestion: $('aiSuggestion'),
  weatherIconLarge: $('weatherIconLarge'),
  tempHigh: $('tempHigh'),
  tempLow: $('tempLow'),
  humidityVal: $('humidityVal'),
  humidityBar: $('humidityBar'),
  windVal: $('windVal'),
  windDir: $('windDir'),
  pressureVal: $('pressureVal'),
  visibilityVal: $('visibilityVal'),
  sunriseVal: $('sunriseVal'),
  sunsetVal: $('sunsetVal'),
  hourlyScroll: $('hourlyScroll'),
  forecastGrid: $('forecastGrid'),
  recentList: $('recentList'),
  recentSection: $('recentSection'),
  greetingText: $('greetingText'),
  greetingTime: $('greetingTime'),
  hamburger: $('hamburger'),
  sidebar: $('sidebar'),
  sidebarClose: $('sidebarClose'),
  voiceModal: $('voiceModal'),
  voiceStatus: $('voiceStatus'),
  voiceCancel: $('voiceCancel'),
  bgLayer: $('bgLayer'),
  rainContainer: $('rainContainer'),
  particlesContainer: $('particlesContainer'),
  ctaLocationBtn: $('ctaLocationBtn'),
  searchSuggestions: $('searchSuggestions'),
  body: document.body,
  html: document.documentElement,
};

/* ════════════════════════════════════════════════════
   WEATHER ICONS & MAPPINGS
════════════════════════════════════════════════════ */

/** Map OpenWeatherMap condition IDs to emoji icons */
function getWeatherIcon(id, isNight = false) {
  if (id >= 200 && id < 300) return '⛈';
  if (id >= 300 && id < 400) return '🌧';
  if (id >= 500 && id < 510) return isNight ? '🌧' : '🌦';
  if (id === 511) return '🌨';
  if (id >= 520 && id < 600) return '🌧';
  if (id >= 600 && id < 700) return '❄';
  if (id === 611 || id === 612 || id === 613) return '🌨';
  if (id >= 700 && id < 800) return '🌫';
  if (id === 800) return isNight ? '🌙' : '☀';
  if (id === 801) return isNight ? '🌤' : '🌤';
  if (id === 802) return '⛅';
  if (id === 803 || id === 804) return '☁';
  return '🌡';
}

/** Return the CSS class for dynamic weather background */
function getWeatherThemeClass(id, isNight = false) {
  if (isNight) return 'weather-night';
  if (id >= 200 && id < 300) return 'weather-thunder';
  if (id >= 300 && id < 600) return 'weather-rain';
  if (id >= 600 && id < 700) return 'weather-snow';
  if (id === 800 || id === 801) return 'weather-sunny';
  return 'weather-default';
}

/** AI-like contextual suggestions */
function getAiSuggestion(weather) {
  const { id, main } = weather;
  const temp = state.unit === 'metric' ? main.temp : (main.temp - 32) / 1.8;
  const suggestions = [];

  if (id >= 200 && id < 300) suggestions.push('⚡ Thunderstorm alert — stay indoors if possible.');
  else if (id >= 300 && id < 600) suggestions.push('☔ Rain expected — carry an umbrella.');
  else if (id >= 600 && id < 700) suggestions.push('🧥 Dress warmly, icy conditions ahead.');
  else if (id >= 700 && id < 800) suggestions.push('🌫 Reduced visibility — drive carefully.');
  else if (id === 800) suggestions.push('😎 Clear skies — perfect for outdoor activities!');
  else if (id >= 801) suggestions.push('🌤 Partly cloudy, enjoy your day.');

  if (temp > 35) suggestions.push('🥵 Extreme heat — stay hydrated!');
  else if (temp > 28) suggestions.push('💧 Hot day — drink plenty of water.');
  else if (temp < 0) suggestions.push('🧊 Below freezing — watch for ice.');
  else if (temp < 10) suggestions.push('🧥 Cold outside — bundle up!');

  if (main.humidity > 80) suggestions.push('💦 High humidity — feels muggy.');

  return suggestions.length > 0 ? suggestions[0] : '✨ Have a wonderful day!';
}

/* ════════════════════════════════════════════════════
   API LAYER
════════════════════════════════════════════════════ */

/**
 * Core fetch wrapper with error handling
 * @param {string} url
 * @returns {Promise<Object>}
 */
async function apiFetch(url) {
  const response = await fetch(url);
  if (!response.ok) {
    if (response.status === 404) throw new Error('City not found. Please try another name.');
    if (response.status === 401) throw new Error('Invalid API key. Check your OpenWeatherMap key.');
    throw new Error(`Weather service error (${response.status}). Try again later.`);
  }
  return response.json();
}

/**
 * Fetch current weather by city name
 * @param {string} city
 */
async function fetchWeatherByCity(city) {
  const units = state.unit;
  const url = `${CONFIG.BASE_URL}/weather?q=${encodeURIComponent(city)}&units=${units}&appid=${CONFIG.API_KEY}`;
  return apiFetch(url);
}

/**
 * Fetch current weather by coordinates
 * @param {number} lat
 * @param {number} lon
 */
async function fetchWeatherByCoords(lat, lon) {
  const units = state.unit;
  const url = `${CONFIG.BASE_URL}/weather?lat=${lat}&lon=${lon}&units=${units}&appid=${CONFIG.API_KEY}`;
  return apiFetch(url);
}

/**
 * Fetch 5-day / 3-hour forecast (gives us ~40 data points)
 * @param {number} lat
 * @param {number} lon
 */
async function fetchForecast(lat, lon) {
  const units = state.unit;
  const url = `${CONFIG.BASE_URL}/forecast?lat=${lat}&lon=${lon}&units=${units}&appid=${CONFIG.API_KEY}`;
  return apiFetch(url);
}

/**
 * Fetch city suggestions for autocomplete
 * @param {string} query
 */
async function fetchCitySuggestions(query) {
  if (query.length < 3) return [];
  const url = `${CONFIG.GEOCODE_URL}/direct?q=${encodeURIComponent(query)}&limit=5&appid=${CONFIG.API_KEY}`;
  try {
    return await apiFetch(url);
  } catch {
    return [];
  }
}

/* ════════════════════════════════════════════════════
   MAIN DATA ORCHESTRATION
════════════════════════════════════════════════════ */

/**
 * Primary function: load weather for a city name
 * @param {string} city
 */
async function loadWeatherForCity(city) {
  if (!city.trim()) return;
  showLoading(true);
  clearError();
  closeSidebar();

  try {
    const weather = await fetchWeatherByCity(city);
    const { lat, lon } = weather.coord;
    const forecast = await fetchForecast(lat, lon);

    state.currentWeather = weather;
    state.forecastData = forecast;

    renderAll(weather, forecast);
    saveLastCity(city);
    addRecentCity(city, weather.main.temp);
  } catch (err) {
    showError(err.message);
    showEmptyState();
  } finally {
    showLoading(false);
  }
}

/**
 * Load weather by GPS coordinates
 * @param {number} lat
 * @param {number} lon
 */
async function loadWeatherByCoords(lat, lon) {
  showLoading(true);
  clearError();
  closeSidebar();

  try {
    const weather = await fetchWeatherByCoords(lat, lon);
    const forecast = await fetchForecast(lat, lon);

    state.currentWeather = weather;
    state.forecastData = forecast;

    renderAll(weather, forecast);
    saveLastCity(weather.name);
    addRecentCity(weather.name, weather.main.temp);
  } catch (err) {
    showError(err.message);
    showEmptyState();
  } finally {
    showLoading(false);
  }
}

/* ════════════════════════════════════════════════════
   RENDER ENGINE
════════════════════════════════════════════════════ */

/**
 * Master render — updates all UI sections
 */
function renderAll(weather, forecast) {
  renderHero(weather);
  renderStats(weather);
  renderHourly(forecast.list);
  renderForecast(forecast.list);
  renderChart(forecast.list);
  applyWeatherTheme(weather);
  DOM.weatherDashboard.hidden = false;
  DOM.emptyState.hidden = true;
}

/**
 * Render hero card (temp, city, condition)
 */
function renderHero(weather) {
  const { name, main, weather: conditions, wind, sys, timezone } = weather;
  const cond = conditions[0];
  const isNight = isNightTime(sys.sunrise, sys.sunset, timezone);
  const icon = getWeatherIcon(cond.id, isNight);
  const unitSymbol = state.unit === 'metric' ? '°C' : '°F';
  const tempRounded = Math.round(main.temp);
  const feelsRounded = Math.round(main.feels_like);
  const highRounded = Math.round(main.temp_max);
  const lowRounded = Math.round(main.temp_min);

  DOM.cityName.textContent = name;
  DOM.countryName.textContent = sys.country;
  DOM.localTime.textContent = getLocalTime(timezone);
  DOM.tempMain.textContent = tempRounded;
  DOM.tempUnit.textContent = unitSymbol;
  DOM.feelsLike.textContent = `Feels like ${feelsRounded}${unitSymbol}`;
  DOM.conditionBadge.textContent = capitalise(cond.description);
  DOM.weatherIconLarge.textContent = icon;
  DOM.tempHigh.textContent = `${highRounded}${unitSymbol}`;
  DOM.tempLow.textContent = `${lowRounded}${unitSymbol}`;
  DOM.aiSuggestion.textContent = getAiSuggestion(weather);
}

/**
 * Render stats grid cards
 */
function renderStats(weather) {
  const { main, wind, visibility, sys, timezone } = weather;
  const windLabel = state.unit === 'metric' ? 'km/h' : 'mph';
  const windSpeed = state.unit === 'metric'
    ? Math.round(wind.speed * 3.6)
    : Math.round(wind.speed);
  const visKm = visibility ? (visibility / 1000).toFixed(1) + ' km' : 'N/A';

  DOM.humidityVal.textContent = `${main.humidity}%`;
  DOM.humidityBar.style.width = `${main.humidity}%`;
  DOM.windVal.textContent = `${windSpeed} ${windLabel}`;
  DOM.windDir.textContent = `Direction: ${degreesToDirection(wind.deg)}`;
  DOM.pressureVal.textContent = `${main.pressure} hPa`;
  DOM.visibilityVal.textContent = visKm;
  DOM.sunriseVal.textContent = formatTime(sys.sunrise + timezone);
  DOM.sunsetVal.textContent = formatTime(sys.sunset + timezone);
}

/**
 * Render hourly forecast strip
 */
function renderHourly(list) {
  const unitSymbol = state.unit === 'metric' ? '°' : '°';
  const next12 = list.slice(0, 8); // 3-hr intervals × 8 = 24 hours

  DOM.hourlyScroll.innerHTML = next12.map((item, idx) => {
    const time = idx === 0 ? 'Now' : formatHour(item.dt);
    const icon = getWeatherIcon(item.weather[0].id);
    const temp = Math.round(item.main.temp);
    const precip = item.pop > 0.1 ? `💧${Math.round(item.pop * 100)}%` : '';

    return `
      <div class="hourly-item ${idx === 0 ? 'now' : ''}">
        <div class="hourly-time">${time}</div>
        <div class="hourly-icon">${icon}</div>
        <div class="hourly-temp">${temp}${unitSymbol}</div>
        ${precip ? `<div class="hourly-precip">${precip}</div>` : ''}
      </div>
    `;
  }).join('');
}

/**
 * Render 7-day forecast grid
 */
function renderForecast(list) {
  // Group by day and pick daily high/low
  const dailyMap = {};
  list.forEach(item => {
    const date = new Date((item.dt + (state.currentWeather?.timezone || 0)) * 1000);
    const key = date.toDateString();
    if (!dailyMap[key]) {
      dailyMap[key] = {
        dt: item.dt,
        temps: [],
        icons: [],
        descriptions: [],
        pops: [],
      };
    }
    dailyMap[key].temps.push(item.main.temp);
    dailyMap[key].icons.push(item.weather[0].id);
    dailyMap[key].descriptions.push(item.weather[0].description);
    dailyMap[key].pops.push(item.pop || 0);
  });

  const days = Object.values(dailyMap).slice(0, 7);
  const unitSymbol = state.unit === 'metric' ? '°C' : '°F';

  DOM.forecastGrid.innerHTML = days.map((day, idx) => {
    const date = new Date(day.dt * 1000);
    const dayName = idx === 0 ? 'Today' : date.toLocaleDateString('en-US', { weekday: 'short' });
    const high = Math.round(Math.max(...day.temps));
    const low = Math.round(Math.min(...day.temps));
    // Most frequent icon
    const iconId = mostFrequent(day.icons);
    const icon = getWeatherIcon(iconId);
    const desc = mostFrequent(day.descriptions);

    return `
      <div class="forecast-card ${idx === 0 ? 'today' : ''}">
        <div class="fc-day">${dayName}</div>
        <div class="fc-icon">${icon}</div>
        <div class="fc-high">${high}${unitSymbol}</div>
        <div class="fc-low">${low}${unitSymbol}</div>
        <div class="fc-desc">${capitalise(desc)}</div>
      </div>
    `;
  }).join('');
}

/**
 * Render Chart.js temperature trend
 */
function renderChart(list) {
  const labels = list.slice(0, 16).map(item => {
    const date = new Date(item.dt * 1000);
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
  });
  const temps = list.slice(0, 16).map(item => Math.round(item.main.temp));
  const feelsLike = list.slice(0, 16).map(item => Math.round(item.main.feels_like));

  const isDark = state.theme === 'dark';
  const gridColor = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
  const tickColor = isDark ? 'rgba(240,246,255,0.4)' : 'rgba(13,26,46,0.45)';

  if (state.chartInstance) state.chartInstance.destroy();

  const ctx = document.getElementById('tempChart').getContext('2d');
  state.chartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [
        {
          label: 'Temperature',
          data: temps,
          borderColor: '#63b3ed',
          backgroundColor: 'rgba(99,179,237,0.08)',
          fill: true,
          tension: 0.4,
          pointRadius: 4,
          pointBackgroundColor: '#63b3ed',
          borderWidth: 2,
        },
        {
          label: 'Feels Like',
          data: feelsLike,
          borderColor: '#f6ad55',
          backgroundColor: 'transparent',
          borderDash: [5, 5],
          tension: 0.4,
          pointRadius: 3,
          pointBackgroundColor: '#f6ad55',
          borderWidth: 1.5,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { intersect: false, mode: 'index' },
      plugins: {
        legend: {
          labels: {
            color: tickColor,
            font: { family: "'Outfit', sans-serif", size: 11 },
            boxWidth: 12,
          },
        },
        tooltip: {
          backgroundColor: isDark ? 'rgba(12,20,38,0.95)' : 'rgba(255,255,255,0.95)',
          titleColor: isDark ? '#f0f6ff' : '#0d1a2e',
          bodyColor: isDark ? 'rgba(240,246,255,0.7)' : 'rgba(13,26,46,0.7)',
          borderColor: isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)',
          borderWidth: 1,
          padding: 12,
          cornerRadius: 10,
        },
      },
      scales: {
        x: {
          grid: { color: gridColor },
          ticks: {
            color: tickColor,
            font: { family: "'Space Mono', monospace", size: 9 },
            maxTicksLimit: 8,
          },
          border: { color: gridColor },
        },
        y: {
          grid: { color: gridColor },
          ticks: {
            color: tickColor,
            font: { family: "'Space Mono', monospace", size: 9 },
            callback: val => `${val}°`,
          },
          border: { color: gridColor },
        },
      },
    },
  });
}

/* ════════════════════════════════════════════════════
   WEATHER THEME ENGINE
════════════════════════════════════════════════════ */

/**
 * Apply dynamic background & rain/snow effects
 */
function applyWeatherTheme(weather) {
  const cond = weather.weather[0];
  const { sys, timezone } = weather;
  const isNight = isNightTime(sys.sunrise, sys.sunset, timezone);
  const themeClass = getWeatherThemeClass(cond.id, isNight);

  // Remove all weather classes
  const weatherClasses = ['weather-default','weather-sunny','weather-rain','weather-snow','weather-thunder','weather-night'];
  DOM.body.classList.remove(...weatherClasses);
  DOM.body.classList.add(themeClass);

  // Rain effect
  const isRainy = cond.id >= 300 && cond.id < 600;
  const isSunny = cond.id === 800 || cond.id === 801;
  toggleRain(isRainy);
  toggleParticles(isSunny && !isNight);
}

function toggleRain(on) {
  DOM.rainContainer.innerHTML = '';
  if (!on) return;
  for (let i = 0; i < 80; i++) {
    const drop = document.createElement('div');
    drop.className = 'raindrop';
    const left = Math.random() * 100;
    const height = 10 + Math.random() * 30;
    const duration = 0.5 + Math.random() * 0.8;
    const delay = Math.random() * 2;
    drop.style.cssText = `
      left:${left}%;
      height:${height}px;
      animation-duration:${duration}s;
      animation-delay:-${delay}s;
      opacity:${0.3 + Math.random() * 0.5};
    `;
    DOM.rainContainer.appendChild(drop);
  }
}

function toggleParticles(on) {
  DOM.particlesContainer.innerHTML = '';
  if (!on) return;
  for (let i = 0; i < 20; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    const left = Math.random() * 100;
    const duration = 8 + Math.random() * 12;
    const delay = Math.random() * 8;
    const dx = (Math.random() - 0.5) * 100;
    p.style.cssText = `
      left:${left}%;
      bottom: -10px;
      animation-duration:${duration}s;
      animation-delay:-${delay}s;
      --dx:${dx}px;
      width:${2 + Math.random() * 3}px;
      height:${2 + Math.random() * 3}px;
    `;
    DOM.particlesContainer.appendChild(p);
  }
}

/* ════════════════════════════════════════════════════
   UI STATE HELPERS
════════════════════════════════════════════════════ */

function showLoading(on) {
  state.isLoading = on;
  DOM.loadingOverlay.classList.toggle('active', on);
  if (on) DOM.weatherDashboard.hidden = true;
}

function showEmptyState() {
  DOM.emptyState.hidden = false;
  DOM.weatherDashboard.hidden = true;
}

function showError(msg) {
  DOM.errorMsg.textContent = msg;
}

function clearError() {
  DOM.errorMsg.textContent = '';
}

/* ════════════════════════════════════════════════════
   RECENT CITIES
════════════════════════════════════════════════════ */

function loadRecentCities() {
  try {
    state.recentCities = JSON.parse(localStorage.getItem(CONFIG.STORAGE_KEYS.RECENT)) || [];
  } catch {
    state.recentCities = [];
  }
}

function addRecentCity(city, temp) {
  // Remove if already exists
  state.recentCities = state.recentCities.filter(
    c => c.name.toLowerCase() !== city.toLowerCase()
  );
  state.recentCities.unshift({ name: city, temp: Math.round(temp) });
  if (state.recentCities.length > CONFIG.MAX_RECENT) {
    state.recentCities = state.recentCities.slice(0, CONFIG.MAX_RECENT);
  }
  localStorage.setItem(CONFIG.STORAGE_KEYS.RECENT, JSON.stringify(state.recentCities));
  renderRecentCities();
}

function renderRecentCities() {
  if (!state.recentCities.length) {
    DOM.recentSection.style.display = 'none';
    return;
  }
  DOM.recentSection.style.display = 'block';
  const unitSymbol = state.unit === 'metric' ? '°C' : '°F';
  DOM.recentList.innerHTML = state.recentCities.map(city => `
    <div class="recent-item" data-city="${city.name}">
      <span>${city.name}</span>
      <span class="recent-temp">${city.temp}${unitSymbol}</span>
    </div>
  `).join('');

  DOM.recentList.querySelectorAll('.recent-item').forEach(item => {
    item.addEventListener('click', () => loadWeatherForCity(item.dataset.city));
  });
}

function saveLastCity(city) {
  localStorage.setItem(CONFIG.STORAGE_KEYS.LAST_CITY, city);
}

function loadLastCity() {
  return localStorage.getItem(CONFIG.STORAGE_KEYS.LAST_CITY);
}

/* ════════════════════════════════════════════════════
   UNIT TOGGLE
════════════════════════════════════════════════════ */

function toggleUnit() {
  state.unit = state.unit === 'metric' ? 'imperial' : 'metric';
  localStorage.setItem(CONFIG.STORAGE_KEYS.UNIT, state.unit);
  const label = state.unit === 'metric' ? '°C' : '°F';
  DOM.unitToggle.textContent = state.unit === 'metric' ? '°C / °F' : '°F / °C';
  DOM.unitToggleMobile.textContent = label;

  // Reload current data with new unit
  if (state.currentWeather) {
    loadWeatherForCity(state.currentWeather.name);
  }
}

/* ════════════════════════════════════════════════════
   THEME TOGGLE
════════════════════════════════════════════════════ */

function toggleTheme() {
  state.theme = state.theme === 'dark' ? 'light' : 'dark';
  DOM.html.setAttribute('data-theme', state.theme);
  DOM.themeIcon.textContent = state.theme === 'dark' ? '☀' : '🌙';
  localStorage.setItem(CONFIG.STORAGE_KEYS.THEME, state.theme);

  // Re-render chart with new theme colours
  if (state.forecastData) {
    renderChart(state.forecastData.list);
  }
}

/* ════════════════════════════════════════════════════
   GEOLOCATION
════════════════════════════════════════════════════ */

function getUserLocation() {
  if (!navigator.geolocation) {
    showError('Geolocation is not supported by your browser.');
    return;
  }
  showLoading(true);
  navigator.geolocation.getCurrentPosition(
    pos => loadWeatherByCoords(pos.coords.latitude, pos.coords.longitude),
    err => {
      showLoading(false);
      const messages = {
        1: 'Location access denied. Please enable permissions.',
        2: 'Location unavailable. Try searching by city.',
        3: 'Location request timed out.',
      };
      showError(messages[err.code] || 'Could not get your location.');
    },
    { timeout: 10000, maximumAge: 60000 }
  );
}

/* ════════════════════════════════════════════════════
   VOICE SEARCH
════════════════════════════════════════════════════ */

let recognition = null;

function startVoiceSearch() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    showError('Voice search is not supported in this browser. Try Chrome.');
    return;
  }

  recognition = new SpeechRecognition();
  recognition.lang = 'en-US';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  DOM.voiceModal.classList.add('active');
  DOM.voiceBtn.classList.add('active');
  DOM.voiceStatus.textContent = 'Listening… say a city name';

  recognition.start();

  recognition.onresult = (e) => {
    const transcript = e.results[0][0].transcript;
    DOM.cityInput.value = transcript;
    closeVoiceModal();
    loadWeatherForCity(transcript);
  };

  recognition.onerror = (e) => {
    closeVoiceModal();
    showError(`Voice error: ${e.error}. Please try again.`);
  };

  recognition.onend = () => closeVoiceModal();
}

function closeVoiceModal() {
  if (recognition) { recognition.stop(); recognition = null; }
  DOM.voiceModal.classList.remove('active');
  DOM.voiceBtn.classList.remove('active');
}

/* ════════════════════════════════════════════════════
   AUTOCOMPLETE SUGGESTIONS
════════════════════════════════════════════════════ */

let suggestTimeout = null;

async function handleSearchInput(e) {
  const val = e.target.value.trim();
  clearTimeout(suggestTimeout);

  if (val.length < 3) {
    DOM.searchSuggestions.classList.remove('active');
    DOM.searchSuggestions.innerHTML = '';
    return;
  }

  suggestTimeout = setTimeout(async () => {
    const results = await fetchCitySuggestions(val);
    if (!results.length) {
      DOM.searchSuggestions.classList.remove('active');
      return;
    }
    DOM.searchSuggestions.innerHTML = results.map(r =>
      `<div class="suggestion-item" data-city="${r.name}, ${r.country}">
        ${r.name}${r.state ? ', ' + r.state : ''}, ${r.country}
      </div>`
    ).join('');
    DOM.searchSuggestions.classList.add('active');
    DOM.searchSuggestions.querySelectorAll('.suggestion-item').forEach(el => {
      el.addEventListener('click', () => {
        const city = el.dataset.city;
        DOM.cityInput.value = city;
        DOM.searchSuggestions.classList.remove('active');
        loadWeatherForCity(city);
      });
    });
  }, 300);
}

/* ════════════════════════════════════════════════════
   SIDEBAR MOBILE
════════════════════════════════════════════════════ */

function openSidebar() {
  DOM.sidebar.classList.add('open');
  // Create overlay if not present
  let overlay = document.querySelector('.sidebar-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    document.body.appendChild(overlay);
    overlay.addEventListener('click', closeSidebar);
  }
  overlay.classList.add('active');
}

function closeSidebar() {
  DOM.sidebar.classList.remove('open');
  const overlay = document.querySelector('.sidebar-overlay');
  if (overlay) overlay.classList.remove('active');
}

/* ════════════════════════════════════════════════════
   GREETING
════════════════════════════════════════════════════ */

function updateGreeting() {
  const hour = new Date().getHours();
  let greeting, emoji;
  if (hour < 5)       { greeting = 'Good night'; emoji = '🌙'; }
  else if (hour < 12) { greeting = 'Good morning'; emoji = '🌅'; }
  else if (hour < 17) { greeting = 'Good afternoon'; emoji = '☀'; }
  else if (hour < 21) { greeting = 'Good evening'; emoji = '🌆'; }
  else                { greeting = 'Good night'; emoji = '🌙'; }

  DOM.greetingText.textContent = `${emoji} ${greeting}!`;
  DOM.greetingTime.textContent = new Date().toLocaleTimeString('en-US', {
    hour: '2-digit', minute: '2-digit'
  });
}

/* ════════════════════════════════════════════════════
   UTILITY FUNCTIONS
════════════════════════════════════════════════════ */

function capitalise(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/** Find most frequent element in array */
function mostFrequent(arr) {
  const counts = {};
  arr.forEach(v => { counts[v] = (counts[v] || 0) + 1; });
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
}

/** Convert wind degrees to compass direction */
function degreesToDirection(deg) {
  const dirs = ['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW'];
  return dirs[Math.round(deg / 22.5) % 16];
}

/** Format Unix timestamp to HH:MM (UTC offset applied) */
function formatTime(timestamp) {
  const date = new Date(timestamp * 1000);
  return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', timeZone: 'UTC' });
}

/** Format Unix timestamp to hour string */
function formatHour(timestamp) {
  const date = new Date(timestamp * 1000);
  return date.toLocaleTimeString('en-US', { hour: 'numeric', hour12: true });
}

/** Get local time string from timezone offset (seconds) */
function getLocalTime(timezoneOffset) {
  const utc = Date.now() + new Date().getTimezoneOffset() * 60000;
  const local = new Date(utc + timezoneOffset * 1000);
  return local.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
}

/** Check if it's currently night at the location */
function isNightTime(sunrise, sunset, timezone) {
  const utc = Math.floor(Date.now() / 1000) + new Date().getTimezoneOffset() * 60;
  const local = utc + timezone;
  return local < sunrise + timezone || local > sunset + timezone;
}

/* ════════════════════════════════════════════════════
   INITIALISATION
════════════════════════════════════════════════════ */

function init() {
  // Restore persisted preferences
  const savedUnit = localStorage.getItem(CONFIG.STORAGE_KEYS.UNIT);
  const savedTheme = localStorage.getItem(CONFIG.STORAGE_KEYS.THEME);

  if (savedUnit) state.unit = savedUnit;
  if (savedTheme) {
    state.theme = savedTheme;
    DOM.html.setAttribute('data-theme', savedTheme);
    DOM.themeIcon.textContent = savedTheme === 'dark' ? '☀' : '🌙';
  }
  DOM.unitToggle.textContent = state.unit === 'metric' ? '°C / °F' : '°F / °C';
  DOM.unitToggleMobile.textContent = state.unit === 'metric' ? '°C' : '°F';

  // Load recent & greeting
  loadRecentCities();
  renderRecentCities();
  updateGreeting();
  setInterval(updateGreeting, 60000);

  // ── EVENT LISTENERS ──────────────────────────────

  // Search
  DOM.searchBtn.addEventListener('click', () => {
    const city = DOM.cityInput.value.trim();
    if (city) {
      DOM.searchSuggestions.classList.remove('active');
      loadWeatherForCity(city);
    }
  });

  DOM.cityInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const city = DOM.cityInput.value.trim();
      if (city) {
        DOM.searchSuggestions.classList.remove('active');
        loadWeatherForCity(city);
      }
    }
  });

  DOM.cityInput.addEventListener('input', handleSearchInput);

  // Close suggestions when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.search-wrapper') && !e.target.closest('.search-suggestions')) {
      DOM.searchSuggestions.classList.remove('active');
    }
  });

  // Voice
  DOM.voiceBtn.addEventListener('click', startVoiceSearch);
  DOM.voiceCancel.addEventListener('click', closeVoiceModal);

  // Location
  DOM.locationBtn.addEventListener('click', getUserLocation);
  DOM.ctaLocationBtn.addEventListener('click', getUserLocation);

  // Unit toggle
  DOM.unitToggle.addEventListener('click', toggleUnit);
  DOM.unitToggleMobile.addEventListener('click', toggleUnit);

  // Theme
  DOM.themeToggle.addEventListener('click', toggleTheme);

  // Mobile sidebar
  DOM.hamburger.addEventListener('click', openSidebar);
  DOM.sidebarClose.addEventListener('click', closeSidebar);

  // ── AUTO-LOAD ────────────────────────────────────

  const lastCity = loadLastCity();
  if (lastCity) {
    loadWeatherForCity(lastCity);
  } else {
    // Try geolocation silently
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        pos => loadWeatherByCoords(pos.coords.latitude, pos.coords.longitude),
        () => { /* Silently fail, show empty state */ },
        { timeout: 5000, maximumAge: 300000 }
      );
    }
  }
}

// Bootstrap
document.addEventListener('DOMContentLoaded', init);
